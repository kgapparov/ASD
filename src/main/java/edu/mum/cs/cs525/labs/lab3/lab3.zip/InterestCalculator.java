package edu.mum.cs.cs525.labs.lab3;

public interface InterestCalculator {
    double getInterest(double balance);
}
