package edu.mum.cs.cs525.labs.lab4;

public interface CustomerService {
    public void getAccountEntries(Account account);
}
