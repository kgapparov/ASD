package edu.mum.cs.cs525.labs.lab2;

public enum ActionType {
    CREATEACCOUNT, CHECKACCOUNT, CHANGEACOUNT, DEPOSIT, WITHDRAW,TRANSFER
}
