package edu.mum.cs.cs525.labs.skeleton;

public enum AccountType {
    SAVING, CHECKING
}
