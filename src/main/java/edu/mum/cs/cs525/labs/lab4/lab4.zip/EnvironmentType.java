package edu.mum.cs.cs525.labs.lab4;

public enum EnvironmentType {
    PRODUCTION,
    TEST
}
