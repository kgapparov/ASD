package edu.mum.cs.cs525.labs.lab3;

public enum AccountType {
    SAVING, CHECKING
}
