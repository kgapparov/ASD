package edu.mum.cs.cs525.labs.lab5;

public class NoCommand implements Command {
    @Override
    public void execute() {

    }

    @Override
    public void redo() {

    }

    @Override
    public void undo() {

    }
}
