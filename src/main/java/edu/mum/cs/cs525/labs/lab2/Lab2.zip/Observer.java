package edu.mum.cs.cs525.labs.lab2;

public interface Observer {
    void update(Account account , ActionType action);
}
